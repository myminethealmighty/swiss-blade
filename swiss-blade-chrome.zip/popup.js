"use strict";
(() => {
  // extension/popup.ts
  var DEFAULT_STATE = {
    enabled: true,
    blockedToday: 0,
    allowlist: []
  };
  var elements = {
    protectionLabel: document.querySelector("#protectionLabel"),
    toggleProtection: document.querySelector("#toggleProtection"),
    powerIcon: document.querySelector("#powerIcon"),
    blockedToday: document.querySelector("#blockedToday"),
    allowlisted: document.querySelector("#allowlisted"),
    statusDot: document.querySelector("#statusDot"),
    statusText: document.querySelector("#statusText"),
    cropShot: document.querySelector("#cropShot"),
    inspectStorage: document.querySelector("#inspectStorage"),
    clearStorage: document.querySelector("#clearStorage"),
    openOptions: document.querySelector("#openOptions"),
    resetStats: document.querySelector("#resetStats"),
    storagePanel: document.querySelector("#storagePanel"),
    storageSummary: document.querySelector("#storageSummary"),
    storageDetails: document.querySelector("#storageDetails")
  };
  var state = DEFAULT_STATE;
  var latestSnapshot = null;
  var expandedStorageType = null;
  function setStatus(message) {
    elements.statusText.textContent = message;
  }
  function objectCount(value) {
    return Object.keys(value).length;
  }
  function trimValue(value) {
    return value.length > 80 ? `${value.slice(0, 80)}...` : value;
  }
  function renderState() {
    elements.protectionLabel.textContent = state.enabled ? "Blocking ads" : "Paused";
    elements.toggleProtection.classList.toggle("is-on", state.enabled);
    elements.toggleProtection.classList.toggle("is-off", !state.enabled);
    elements.powerIcon.textContent = state.enabled ? "ON" : "OFF";
    elements.statusDot.classList.toggle("on", state.enabled);
    elements.blockedToday.textContent = String(state.blockedToday);
    elements.allowlisted.textContent = String(state.allowlist.length);
  }
  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(response);
      });
    });
  }
  async function readState() {
    state = await chrome.storage.local.get(DEFAULT_STATE);
    state = {
      enabled: Boolean(state.enabled),
      blockedToday: Number(state.blockedToday ?? 0),
      allowlist: Array.isArray(state.allowlist) ? state.allowlist : []
    };
    renderState();
    setStatus(state.enabled ? "Protection active" : "Protection paused");
  }
  async function toggleProtection() {
    const nextEnabled = !state.enabled;
    state = await sendMessage({ type: "setEnabled", enabled: nextEnabled });
    renderState();
    setStatus(state.enabled ? "Protection active" : "Protection paused");
  }
  async function resetStats() {
    state = await sendMessage({ type: "resetStats" });
    renderState();
    setStatus("Stats reset");
  }
  async function takeScreenshot() {
    await sendMessage({ type: "captureVisibleScreenshot" });
    setStatus("Screenshot saved");
  }
  function getStorageCount(snapshot, storageType) {
    if (storageType === "cookies") return snapshot.cookies.length;
    if (storageType === "localStorage") return objectCount(snapshot.localStorage);
    if (storageType === "sessionStorage") return objectCount(snapshot.sessionStorage);
    if (storageType === "indexedDB") return snapshot.indexedDB.length;
    return snapshot.cacheStorage.length;
  }
  function getStorageItems(snapshot, storageType) {
    if (storageType === "cookies") return snapshot.cookies.map((cookie) => `${cookie.name} @ ${cookie.domain}`);
    if (storageType === "localStorage") return Object.entries(snapshot.localStorage).map(([key, value]) => `${key}: ${trimValue(value)}`);
    if (storageType === "sessionStorage") return Object.entries(snapshot.sessionStorage).map(([key, value]) => `${key}: ${trimValue(value)}`);
    if (storageType === "indexedDB") return snapshot.indexedDB;
    return snapshot.cacheStorage;
  }
  function createStorageDetails(snapshot, storageType, label) {
    const details = document.createElement("div");
    const title = document.createElement("h3");
    const list = document.createElement("ul");
    const items = getStorageItems(snapshot, storageType);
    details.className = "storage-inline-details";
    title.textContent = label;
    if (items.length === 0) {
      const item = document.createElement("li");
      item.textContent = "Empty";
      list.append(item);
    } else {
      for (const value of items) {
        const item = document.createElement("li");
        item.textContent = value;
        list.append(item);
      }
    }
    details.append(title, list);
    return details;
  }
  function toggleStorageDetails(storageType) {
    expandedStorageType = expandedStorageType === storageType ? null : storageType;
    if (latestSnapshot) renderStorage(latestSnapshot);
  }
  function renderStorageRow(snapshot, storageType, label) {
    const row = document.createElement("div");
    const header = document.createElement("div");
    const countButton = document.createElement("button");
    const clearButton = document.createElement("button");
    const isExpanded = expandedStorageType === storageType;
    row.className = isExpanded ? "storage-row is-expanded" : "storage-row";
    header.className = "storage-row-header";
    countButton.className = "storage-count-button";
    clearButton.className = "storage-clear-button";
    countButton.type = "button";
    clearButton.type = "button";
    countButton.textContent = `${label} ${getStorageCount(snapshot, storageType)}`;
    clearButton.textContent = "Clear";
    countButton.addEventListener("click", () => toggleStorageDetails(storageType));
    clearButton.addEventListener("click", () => runTool(() => clearStorageType(storageType)));
    header.append(countButton, clearButton);
    row.append(header);
    if (isExpanded) {
      row.append(createStorageDetails(snapshot, storageType, label));
    }
    return row;
  }
  function renderStorage(snapshot) {
    latestSnapshot = snapshot;
    elements.storagePanel.hidden = false;
    elements.storageDetails.hidden = true;
    elements.storageDetails.replaceChildren();
    elements.storageSummary.replaceChildren(
      renderStorageRow(snapshot, "cookies", "Cookies"),
      renderStorageRow(snapshot, "localStorage", "Local"),
      renderStorageRow(snapshot, "sessionStorage", "Session"),
      renderStorageRow(snapshot, "indexedDB", "IDB"),
      renderStorageRow(snapshot, "cacheStorage", "Cache")
    );
  }
  async function inspectStorage() {
    const snapshot = await sendMessage({ type: "inspectActiveTabStorage" });
    if (snapshot.ok === false) throw new Error(snapshot.error ?? "Could not inspect storage");
    renderStorage(snapshot);
    setStatus("Storage inspected");
  }
  async function clearStorageType(storageType) {
    const result = await sendMessage({ type: "clearStorageType", storageType });
    if (!result.ok) throw new Error(result.error ?? "Could not clear storage");
    await inspectStorage();
    setStatus("Storage cleared");
  }
  async function clearStorage() {
    const result = await sendMessage({ type: "clearActiveTabStorage" });
    if (!result.ok) throw new Error(result.error ?? "Could not clear storage");
    latestSnapshot = null;
    expandedStorageType = null;
    elements.storagePanel.hidden = true;
    elements.storageSummary.replaceChildren();
    elements.storageDetails.replaceChildren();
    setStatus(`Cleared storage and ${result.clearedCookies ?? 0} cookies`);
  }
  async function runTool(action) {
    for (const button of [elements.cropShot, elements.inspectStorage, elements.clearStorage]) {
      button.disabled = true;
    }
    try {
      await action();
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Action failed");
    } finally {
      for (const button of [elements.cropShot, elements.inspectStorage, elements.clearStorage]) {
        button.disabled = false;
      }
    }
  }
  elements.toggleProtection.addEventListener("click", () => runTool(toggleProtection));
  elements.resetStats.addEventListener("click", () => runTool(resetStats));
  elements.cropShot.addEventListener("click", () => runTool(takeScreenshot));
  elements.inspectStorage.addEventListener("click", () => runTool(inspectStorage));
  elements.clearStorage.addEventListener("click", () => runTool(clearStorage));
  elements.openOptions.addEventListener("click", () => chrome.runtime.openOptionsPage());
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;
    state = {
      ...state,
      enabled: changes.enabled ? Boolean(changes.enabled.newValue) : state.enabled,
      blockedToday: changes.blockedToday ? Number(changes.blockedToday.newValue ?? 0) : state.blockedToday,
      allowlist: changes.allowlist && Array.isArray(changes.allowlist.newValue) ? changes.allowlist.newValue : state.allowlist
    };
    renderState();
  });
  void readState();
})();
